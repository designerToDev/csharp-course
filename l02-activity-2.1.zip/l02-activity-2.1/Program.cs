﻿double num1 = 4;
double num2 = 2;

double average = num1 + num2;
Console.WriteLine(average / 2);

string myName = "Blake Guffin";
Console.WriteLine(myName.ToUpper());

